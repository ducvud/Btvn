# MongoDB Demo - ExpressJS JWT Backend API với Mongoose

Project này minh họa cách xây dựng backend API bằng ExpressJS, MongoDB, Mongoose ODM và JWT Authentication.

## Chức năng chính

- Register user.
- Login và nhận JWT.
- Lấy thông tin user hiện tại bằng token.
- CRUD books bằng Mongoose model.
- Bảo vệ API thêm, sửa, xóa sách bằng JWT.
- Chia code theo `routes`, `controllers`, `services`, `models`, `middlewares`, `config`, `utils`.
- Bật CORS để frontend ReactJS có thể gọi API.

## Cài đặt

```bash
npm install
```

Tạo file `.env` dựa trên `.env.example`:

```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/library_db
DATABASE_NAME=library_db
JWT_SECRET=your_jwt_secret
JWT_EXPIRES_IN=1h
CLIENT_URL=http://localhost:5173
```

Chạy project:

```bash
npm run dev
```

Hoặc:

```bash
npm start
```

## Cấu trúc project

```text
src/
  app.js
  server.js
  config/
    db.js
  routes/
    authRoutes.js
    bookRoutes.js
  controllers/
    authController.js
    bookController.js
  services/
    authService.js
    bookService.js
  models/
    User.js
    Book.js
  middlewares/
    authMiddleware.js
    errorMiddleware.js
  utils/
    jwt.js
```

## Auth API

| Method | Endpoint | Auth | Chức năng |
| --- | --- | --- | --- |
| `POST` | `/api/auth/register` | Không | Đăng ký user |
| `POST` | `/api/auth/login` | Không | Đăng nhập |
| `GET` | `/api/auth/me` | Có | Lấy thông tin user hiện tại |

### Register

```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"An","email":"an@example.com","password":"123456"}'
```

### Login

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"an@example.com","password":"123456"}'
```

Response login có `token`. Dùng token đó cho API cần đăng nhập:

```text
Authorization: Bearer <token>
```

### Me

```bash
curl http://localhost:3000/api/auth/me \
  -H "Authorization: Bearer <token>"
```

## Books API

| Method | Endpoint | Auth | Chức năng |
| --- | --- | --- | --- |
| `GET` | `/api/books` | Không | Lấy danh sách sách |
| `GET` | `/api/books/:id` | Không | Lấy chi tiết sách |
| `POST` | `/api/books` | Có | Thêm sách |
| `PUT` | `/api/books/:id` | Có | Cập nhật sách |
| `DELETE` | `/api/books/:id` | Có | Xóa sách |

### Lấy danh sách sách theo category

```bash
curl "http://localhost:3000/api/books?category=Programming"
```

### Tạo sách

```bash
curl -X POST http://localhost:3000/api/books \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{"title":"Node.js Basics","author":"Aptech","category":"Programming","available":true}'
```

### Lấy danh sách sách

```bash
curl http://localhost:3000/api/books
```

### Lấy chi tiết sách

```bash
curl http://localhost:3000/api/books/<BOOK_ID>
```

### Cập nhật sách

```bash
curl -X PUT http://localhost:3000/api/books/<BOOK_ID> \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{"title":"Node.js Advanced","available":false}'
```

### Xóa sách

```bash
curl -X DELETE http://localhost:3000/api/books/<BOOK_ID> \
  -H "Authorization: Bearer <token>"
```

## Response format

Thành công:

```json
{
  "success": true,
  "data": {}
}
```

Lỗi:

```json
{
  "success": false,
  "message": "Error message"
}
```

## Ghi chú cho ReactJS frontend

- Backend chạy mặc định tại `http://localhost:3000`.
- ReactJS có thể chạy tại `http://localhost:5173`.
- Sau khi login, frontend dùng token để gọi API protected.
- Header cần gửi:

```text
Authorization: Bearer <token>
```

## Troubleshooting MongoDB Atlas

Nếu chạy server gặp lỗi TLS hoặc `MongoServerSelectionError`, hãy kiểm tra trong MongoDB Atlas:

- Cluster đang ở trạng thái active.
- Database user và password đúng.
- Connection string đúng cluster.
- Network Access List đã allow IP hiện tại.
- Khi học trên lớp có thể tạm allow `0.0.0.0/0`, sau đó thu hẹp lại khi dùng thật.
